# BoneFrection > 2023-10-18 9:56pm
https://universe.roboflow.com/dr-ali-khayeat/bonefrection

Provided by a Roboflow user
License: CC BY 4.0

